
######## Snakemake header ########
library(methods)
Snakemake <- setClass(
    "Snakemake",
    slots = c(
        input = "list",
        output = "list",
        params = "list",
        wildcards = "list",
        threads = "numeric",
        log = "list",
        resources = "list",
        config = "list",
        rule = "character",
        bench_iteration = "numeric",
        scriptdir = "character",
        source = "function"
    )
)
snakemake <- Snakemake(
    input = list('Filtered_GtRNAdbsets.txt', 'FilteredData.txt', "domains_combined" = 'Filtered_GtRNAdbsets.txt', "data" = 'FilteredData.txt'),
    output = list('nmdsplotwithsubmitted.html', "nmds" = 'nmdsplotwithsubmitted.html'),
    params = list(),
    wildcards = list(),
    threads = 1,
    log = list(),
    resources = list(),
    config = list("files" = c('GCF_000015825.1_ASM1582v1_genomic.fna', 'GCF_000017225.1_ASM1722v1_genomic.fna', 'GCF_000337075.1_ASM33707v1_genomic.fna', 'GCF_004310395.1_ASM431039v1_genomic.fna'), "GtRNAdbsets" = c('archaea_GtRNAdb', 'bacteria_GtRNAdb', 'eukaryota_GtRNAdb'), "soort" = c('-A'), "soort_naam" = c('archaea')),
    rule = 'NMDSwithsubmitted',
    bench_iteration = as.numeric(NA),
    scriptdir = '/mnt/c/users/daanv/Documents/Hogeschool/Jaar_3/Bpexa/Pipeline/Archief',
    source = function(...){
        wd <- getwd()
        setwd(snakemake@scriptdir)
        source(...)
        setwd(wd)
    }
)


######## Original script #########
#install.packages("ggplot2")
#install.packages("plotly")
#install.packages("vegan")
#install.packages("viridis")
library(ggplot2)
library(plotly)
library(vegan)
library(viridis)

# Read file
#setwd("C:/Users/judyh/Documents/BPEXA")
mytable <- read.delim(snakemake@input[["domains_combined"]], header = TRUE, sep = "\t")

mytable <- read.delim(snakemake@input[["domains_combined"]], header = TRUE, sep = "\t")
genomes <- read.delim(snakemake@input[["data"]], header = FALSE, sep = "\t")
mytable$ID <- paste(mytable$GenomeID, " (", mytable$Domain ,")")
genomes$ID <- paste(genomes$V2, " (", "Submitted",")")

# Alter table with 1 for presence anti-codon and 0 for absence
anticodons <- data.frame(unclass(table(mytable$ID,mytable$Isotype)))
anticodons.genomes <- data.frame(unclass(table(genomes$ID,genomes$V6)))
anticodons[anticodons > 1] <- 1
anticodons.genomes[anticodons.genomes > 1] <- 1

# Add absent anticodons to matrices and combine
allanticodons <- c('AAA', 'AAC', 'AAG', 'AAT', 'ACA', 'ACC', 'ACG', 'ACT',
                   'AGA', 'AGC', 'AGG', 'AGT', 'ATA', 'ATC', 'ATG', 'ATT',
                   'CAA', 'CAC', 'CAG', 'CAT', 'CCA', 'CCC', 'CCG', 'CCT',
                   'CGA', 'CGC', 'CGG', 'CGT', 'CTA', 'CTC', 'CTG', 'CTT',
                   'GAA', 'GAC', 'GAG', 'GAT', 'GCA', 'GCC', 'GCG', 'GCT',
                   'GGA', 'GGC', 'GGG', 'GGT', 'GTA', 'GTC', 'GTG', 'GTT',
                   'TAA', 'TAC', 'TAG', 'TAT', 'TCA', 'TCC', 'TCG', 'TCT',
                   'TGA', 'TGC', 'TGG', 'TGT', 'TTA', 'TTC', 'TTG', 'TTT')

add_columns = function(matrix){
  zeros <- rep(c(0), times=nrow(matrix))
  for (anticodon in allanticodons){
    if (anticodon %in% colnames(matrix)){
      next
    } else {
      matrix <- cbind(matrix, zeros)
      names(matrix)[ncol(matrix)] <- anticodon
    }
  }
  return(matrix)
}

anticodons <- add_columns(anticodons)
anticodons.genomes <- add_columns(anticodons.genomes)
anticodons <- rbind(anticodons, anticodons.genomes)

# NMDS plot
nmds_results <- metaMDS(comm=anticodons, distance="bray", k=8, try=10)

data_scores <- as.data.frame(scores(nmds_results))
data_scores$Domain <- sapply(strsplit(rownames(data_scores), " "), "[", 4)
data_scores$GenomeID <- sapply(strsplit(rownames(data_scores), " "), "[", 1)

nmds_plot <- ggplot(data=data_scores, aes(x=NMDS1, y=NMDS2, label=GenomeID, color=Domain)) +
  geom_point(aes(shape=Domain)) + 
  scale_shape_manual(values=c(1, 4, 17, 20)) +
  ggtitle("NMDS plot of genomes")
nmds_plot_i <- ggplotly(nmds_plot)
nmds_plot_i


####
data(anticodons)
MDS <- cmdscale(vegdist(anticodons, method = "bray"), k=8, eig = T, add = T )
round(MDS$eig*100/sum(MDS$eig),1)
n = 8
stress <- vector(length = n)
for (i in 1:n) {
  stress[i] <- metaMDS(anticodons, distance = "bray", k = i)$stress
}
names(stress) <- paste0(1:n, "Dim")
# x11(width = 10/2.54, height = 7/2.54)
par(mar = c(3.5,3.5,1,1), mgp = c(2, 0.6, 0), cex = 0.8, las = 2)
barplot(stress, ylab = "stress")
####


htmlwidgets::saveWidget(as_widget(nmds_plot_i), "nmdsplotwithsubmitted.html")






